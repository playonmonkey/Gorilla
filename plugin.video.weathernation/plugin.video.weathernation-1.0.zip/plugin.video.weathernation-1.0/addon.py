import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon('plugin.video.weathernation')
title = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')
link = 'http://cdnapi.kaltura.com/p/931702/sp/93170200/playManifest/entryId/1_oorxcge2/format/applehttp/protocol/http/uiConfId/28428751/a.m3u8'

li = xbmcgui.ListItem(label=title, iconImage=icon, thumbnailImage=icon, path=link)
li.setInfo(type='Video', infoLabels={ "title": title })
li.setProperty('IsPlayable', 'true')

xbmc.Player().play(item=link, listitem=li)