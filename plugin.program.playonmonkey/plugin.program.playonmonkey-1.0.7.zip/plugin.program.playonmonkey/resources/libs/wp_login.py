# -*- coding: utf-8 -*-
# Author: cody@code-sandbox.net (2017)
import re
import requests

import xbmc
import xbmcgui
import xbmcaddon

################################################################################
# Addon constants
################################################################################

ADDON_ID = 'plugin.program.playonmonkey'
ADDON = xbmcaddon.Addon(ADDON_ID)
DIALOG = xbmcgui.Dialog()

################################################################################
# String constants
################################################################################

TAG = 'SW_DEBUG/ '
PRIV_ACCESS_MSG = '''
Setup login options for Private Access in wizard settings
or visit [B]playonmonkeys.net[/B] to register a new account.
'''

################################################################################
# Module URL's
################################################################################

BASE_URL = 'https://playonmonkeys.net/'

WP_LOGIN = BASE_URL + 'member-login/'
WP_REDIRECT = BASE_URL + 'my-account/'

################################################################################
# Request constants
################################################################################

HEADERS = {
    'Cookie': 'eMember_in_use=eMember; comment_author_=eMember;', 
    'Referer': WP_LOGIN
}

################################################################################
# Regex patterns
################################################################################

META_PATTERN = 'og:description" content="(.+?)"'

################################################################################
# Class definitions
################################################################################

class WpUser:

    LEVEL_1 = BASE_URL + 'ps1/'  # verify permissions for level 1 users
    LEVEL_2 = BASE_URL + 'ps2/'  # verify permissions for level 2 users

    @staticmethod
    def is_valid(clearance=WP_REDIRECT):

        uname = ADDON.getSetting('uname')
        passwd = ADDON.getSetting('passwd')

        if uname == '' or passwd == '':
            DIALOG.ok('Access Restricted', PRIV_ACCESS_MSG)
            return False

        form_data={
            'wp_http_referer': '/member-login/',
            'login_user_name': uname,
            'login_pwd': passwd,
            'testcookie': '1',
            'doLogin': 'Login'
        }

        results = ''
        try:
            with requests.Session() as s:

                s.post(WP_LOGIN, headers=HEADERS, data=form_data)
                resp = s.get(clearance)

                results = re.findall(META_PATTERN, resp.text)[0]

        except Exception as err:
            DIALOG.ok('Error', 'PrivateAccess login error: {}'.format(err))

        if results.startswith("Please Login") or \
            results.startswith("You do not have permission"):
            DIALOG.ok('Access Restricted', PRIV_ACCESS_MSG)
            xbmc.log(TAG + 'Invalid user.', xbmc.LOGDEBUG)
        else:
            xbmc.log(TAG + 'Valid user', xbmc.LOGDEBUG)
            return True
            
        return False
